package edu.cs3500.spreadsheets.model;

/**
 * To represent a type of function, which is also a formula. The main functions are
 * SUM/PRODUCT/LESSTHAN/CONCAT.
 */
public interface Function extends Formula {

}
