package edu.cs3500.spreadsheets.view;

public interface SpreadsheetView {

  void render();
  
}
